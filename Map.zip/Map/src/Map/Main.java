package Map;

import Map.View.*;

public class Main
{
	public static void main(String[] args) {

		FirstWindow firstWindow = new FirstWindow();
		
	}
}